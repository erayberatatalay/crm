<?php
// created: 2025-04-21 18:23:08
$dictionary["AOS_Products"]["fields"]["rc_productpricing_aos_products"] = array (
  'name' => 'rc_productpricing_aos_products',
  'type' => 'link',
  'relationship' => 'rc_productpricing_aos_products',
  'source' => 'non-db',
  'module' => 'RC_ProductPricing',
  'bean_name' => 'RC_ProductPricing',
  'side' => 'right',
  'vname' => 'LBL_RC_PRODUCTPRICING_AOS_PRODUCTS_FROM_RC_PRODUCTPRICING_TITLE',
);
