{
    "sEmptyTable":     "Tabloda herhangi bir veri yok",
    "sInfo":           "_TOTAL_ kayıttan _START_ ile _END_ arası görüntüleniyor",
    "sInfoEmpty":      "0 ile 0 arasındaki kayıtlar görüntüleniyor. Toplam 0 kayıt",
    "sInfoFiltered":   "(_MAX_ toplam kayıttan süzüldü)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "_MENU_ ögelerini görüntüle",
    "sLoadingRecords": "Yükleniyor...",
    "sProcessing":     "İşleniyor...",
    "sSearch":         "Arama:",
    "sZeroRecords":    "Eşleşen bir kayıt bulunamadı",
    "oPaginate": {
        "sFirst":    "İlk",
        "sLast":     "Son",
        "sNext":     "Sonraki",
        "sPrevious": "Önceki"
    },
    "oAria": {
        "sSortAscending":  ": artan sütun sıralaması için etkinleştirin",
        "sSortDescending": ": azalan sütun sıralaması için etkinleştirin"
    }
}