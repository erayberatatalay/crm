<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_MODULE_NAME' => 'Ana Sayfa',
    'LBL_NEW_FORM_TITLE' => 'Yeni İlgili Kişi',
    'LBL_FIRST_NAME' => 'Ad:',
    'LBL_LAST_NAME' => 'Soyad:',
    'LBL_LIST_LAST_NAME' => 'Soyad',
    'LBL_PHONE' => 'Telefon:',
    'LBL_EMAIL_ADDRESS' => 'E-posta:',
    'LBL_MY_PIPELINE_FORM_TITLE' => 'Satış Olasılığım',
    'LBL_PIPELINE_FORM_TITLE' => 'Satış Aşamalarına Göre Satış Olasılıkları',
    'LBL_RGraph_PIPELINE_FORM_TITLE' => 'Satış Aşamalarına Göre Satış Olasılıkları',
    'LNK_NEW_CONTACT' => 'Kişi Ekle',
    'LNK_NEW_ACCOUNT' => 'Hesap Ekle',
    'LNK_NEW_OPPORTUNITY' => 'Fırsat Ekle',
    'LNK_NEW_LEAD' => 'Potansiyel Ekle',
    'LNK_NEW_CASE' => 'Destek Kaydı Ekle',
    'LNK_NEW_NOTE' => 'Not ya da Dosya Ekle',
    'LNK_NEW_CALL' => 'Telefon Aramasını Günlüğe Kaydet',
    'LNK_NEW_EMAIL' => 'E-postayı Arşivle',
    'LNK_NEW_MEETING' => 'Toplantı Zamanla',
    'LNK_NEW_TASK' => 'Görev Ekle',
    'LNK_NEW_BUG' => 'Hata Raporla',
    'LNK_NEW_SEND_EMAIL' => 'Yeni E-posta',
    'LBL_NO_ACCESS' => 'Bu bölüme erişme izniniz yok. İzin almak için site yöneticiniz ile görüşün',
    'LBL_NO_RESULTS_IN_MODULE' => '-- Sonuç Yok --',
    'LBL_NO_RESULTS' => '<h2>Herhangi bir sonuç bulunamadı. Lütfen yeniden arayın.</h2><br>',
    'LBL_NO_RESULTS_TIPS' => '<h3>Arama İpuçları:</h3><ul><li>Yukarıdan uygun kategoriyi seçtiğinizden emin olun.</li><li>Arama ölçütlerini genişletin.</li><li>Gene de bir sonuç bulunamıyorsa gelişmiş arama seçeneğini kullanın.</li></ul>',

    'LBL_ADD_DASHLETS' => 'SuiteCRM Pano Bileşenleri Ekle',
    'LBL_WEBSITE_TITLE' => 'Web Sitesi',
    'LBL_RSS_TITLE' => 'Haber Akışı',
    'LBL_CLOSE_DASHLETS' => 'Kapat',
    'LBL_OPTIONS' => 'Ayarlar',
    // dashlet search fields
    'LBL_TODAY' => 'Bugün',
    'LBL_YESTERDAY' => 'Dün',
    'LBL_TOMORROW' => 'Yarın',
    'LBL_NEXT_WEEK' => 'Gelecek Hafta',
    'LBL_LAST_7_DAYS' => 'Son 7 gün',
    'LBL_NEXT_7_DAYS' => 'Gelecek 7 Gün',
    'LBL_LAST_MONTH' => 'Geçen Ay',
    'LBL_NEXT_MONTH' => 'Sonraki Ay',
    'LBL_LAST_YEAR' => 'Geçen Yıl',
    'LBL_NEXT_YEAR' => 'Sonraki Yıl',
    'LBL_LAST_30_DAYS' => 'Son 30 Gün',
    'LBL_NEXT_30_DAYS' => 'Gelecek 30 Gün',
    'LBL_THIS_MONTH' => 'Bu Ay',
    'LBL_THIS_YEAR' => 'Bu Yıl',

    'LBL_MODULES' => 'Modüller',
    'LBL_CHARTS' => 'Çizelgeler',
    'LBL_TOOLS' => 'Araçlar',
    'LBL_WEB' => 'Web',
    'LBL_SEARCH_RESULTS' => 'Arama Sonuçları',

    // Dashlet Categories
    'dashlet_categories_dom' => array(
        'Module Views' => 'Modül Görünümleri',
        'Portal' => 'Portal',
        'Charts' => 'Çizelgeler',
        'Tools' => 'Araçlar',
        'Miscellaneous' => 'Diğerleri'
    ),
    'LBL_ADDING_DASHLET' => 'SuiteCRM Pano Bileşeni Ekleniyor...',
    'LBL_ADDED_DASHLET' => 'SuiteCRM Pano Bileşeni Eklendi',
    'LBL_REMOVE_DASHLET_CONFIRM' => 'Bu SuiteCRM pano bileşenini kaldırmak istediğinize emin misiniz?',
    'LBL_REMOVING_DASHLET' => 'SuiteCRM Pano Bileşeni Kaldırılıyor...',
    'LBL_REMOVED_DASHLET' => 'SuiteCRM Pano Bileşeni Kaldırıldı',
    'LBL_DASHLET_CONFIGURE_GENERAL' => 'Genel',
    'LBL_DASHLET_CONFIGURE_FILTERS' => 'Süzgeçler',
    'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Yalnız Benim Ögelerim',
    'LBL_DASHLET_CONFIGURE_TITLE' => 'Başlık',
    'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Görüntülenecek Satır',

    'LBL_DASHLET_DELETE' => 'SuiteCRM Pano Bileşenini Sil',
    'LBL_DASHLET_REFRESH' => 'SuiteCRM Pano Bileşenini Yenile',
    'LBL_DASHLET_EDIT' => 'SuiteCRM Pano Bileşenini Düzenle',

    // Default out-of-box names for tabs
    'LBL_HOME_PAGE_1_NAME' => 'SuiteCRM Panom',
    'LBL_CLOSE_SITEMAP' => 'Kapat',

    'LBL_SEARCH' => 'Arama',
    'LBL_CLEAR' => 'Temizle',

    'LBL_BASIC_CHARTS' => 'Temel Çizelgeler',

    'LBL_DASHLET_SEARCH' => 'SuiteCRM Pano Bileşeni Arama',

//ABOUT page
    'LBL_VERSION' => 'Sürüm',
    'LBL_BUILD' => 'Oluştur',

    'LBL_SOURCE_SUGAR' => 'SugarCRM Inc - CE çatısının geliştiricileri',

    'LBL_DASHLET_TITLE' => 'Sitelerim',
    'LBL_DASHLET_OPT_TITLE' => 'Başlık',
    'LBL_DASHLET_INCORRECT_URL' => 'Belirtilen web sitesi konumu yanlış',
    'LBL_DASHLET_OPT_URL' => 'Web Sitesinin Konumu',
    'LBL_DASHLET_OPT_HEIGHT' => 'Pano Bileşeninin Yüksekliği (piksel)',
    'LBL_DASHLET_SUITE_NEWS' => 'SuiteCRM Haberleri',
    'LBL_DASHLET_DISCOVER_SUITE' => 'SuiteCRM Özelliklerini Keşfedin',
    'LBL_BASIC_SEARCH' => 'Hızlı Süzgeç' /*for 508 compliance fix*/,
    'LBL_ADVANCED_SEARCH' => 'Gelişmiş Süzgeç' /*for 508 compliance fix*/,
    'LBL_TOUR_HOME' => 'Ana Sayfa Simgesi',
    'LBL_TOUR_HOME_DESCRIPTION' => 'Ana Sayfaya tek bir tıklamayla hızlıca geri dönebilirsiniz.',
    'LBL_TOUR_MODULES' => 'Modüller',
    'LBL_TOUR_MODULES_DESCRIPTION' => 'Önemli tüm modülleriniz burada bulunur.',
    'LBL_TOUR_MORE' => 'Diğer Modüller',
    'LBL_TOUR_MORE_DESCRIPTION' => 'Modüllerin geri kalanı burada bulunur.',
    'LBL_TOUR_SEARCH' => 'Tam Metin Arama',
    'LBL_TOUR_SEARCH_DESCRIPTION' => 'Arama çok daha iyi hale geldi.',
    'LBL_TOUR_NOTIFICATIONS' => 'Bildirimler',
    'LBL_TOUR_NOTIFICATIONS_DESCRIPTION' => 'SuiteCRM uygulama bildirimleri burada bulunur.',
    'LBL_TOUR_PROFILE' => 'Profil',
    'LBL_TOUR_PROFILE_DESCRIPTION' => 'Profil erişimi, ayarlar ve oturum kapatma.',
    'LBL_TOUR_QUICKCREATE' => 'Hızlı Ekle',
    'LBL_TOUR_QUICKCREATE_DESCRIPTION' => 'Bulunduğunuz yeri kaybetmeden hızlıca kayıtlar ekleyebilirsiniz.',
    'LBL_TOUR_FOOTER' => 'Daraltılabilir Alt Bilgi',
    'LBL_TOUR_FOOTER_DESCRIPTION' => 'Alt bilgi bölümünü kolayca genişletip daraltabilirsiniz.',
    'LBL_TOUR_CUSTOM' => 'Özel Uygulamalar',
    'LBL_TOUR_CUSTOM_DESCRIPTION' => 'Özel bütünleştirmeler burada bulunur.',
    'LBL_TOUR_BRAND' => 'Markanız',
    'LBL_TOUR_BRAND_DESCRIPTION' => 'Logonuz burada bulunur. Ayrıntılı bilgi almak için fare ile üzerine gelebilirsiniz.',
    'LBL_TOUR_WELCOME' => 'SuiteCRM Uygulamasına Hoş Geldiniz',
    'LBL_TOUR_WATCH' => 'SuiteCRM Üzerindeki Yeniliklere Bakın',
    'LBL_TOUR_FEATURES' => '<ul style=""><li class="icon-ok">Yeni basitleştirilmiş gezinme çubuğu</li><li class="icon-ok">Yeni daraltılabilir alt bilgi</li><li class="icon-ok">Geliştirilmiş arama
</li><li class="icon-ok">Güncellenmiş işlemler menüsü</li></ul><p>ve daha fazlası!
</p>',
    'LBL_TOUR_VISIT' => 'Ayrıntılı bilgi almak için lütfen uygulamamıza bakın',
    'LBL_TOUR_DONE' => 'İşte bu kadar!',
    'LBL_TOUR_REFERENCE_1' => 'Profil sekmesindeki "Destek Forumu" bağlantısını kullanarak',
    'LBL_TOUR_REFERENCE_2' => 'üzerinden bilgi alabilirsiniz.',
    'LNK_TOUR_DOCUMENTATION' => 'belgeler',
    'LBL_TOUR_CALENDAR_URL_1' => 'SuiteCRM takviminizi Microsoft Outlook ya da Exchange gibi üçüncü taraf uygulamaları ile paylaşıyor musunuz? Paylaşım adresi yenilendi. Bu yeni ve daha güvenli adreste takviminize izni olmayan kişiler tarafından erişilmesini engelleyen bir kişisel anahtar bulunuyor.',
    'LBL_TOUR_CALENDAR_URL_2' => 'Yeni paylaşılan takvim adresinizi alın.',
    'LBL_CONTRIBUTORS' => 'Katkıda Bulunanlar',
    'LBL_ABOUT_SUITE' => 'SuiteCRM Hakkında',
    'LBL_PARTNERS' => 'İş Ortakları',
    'LBL_FEATURING' => 'SalesAgility tarafından AOS, AOW, AOR, AOP, AOE ve Yeniden Zamanlama modülleri geliştirildi.',
    'LBL_EDIT_ALL_RECURRENCES' => 'Tüm Yinelenmeleri Düzenle',
    'LBL_REMOVE_ALL_RECURRENCES' => 'Bütün Yinelenmeleri Sil',
    'LBL_CONFIRM_REMOVE' => 'Bu kaydı silmek istediğinize emin misiniz?',

    'LBL_CONTRIBUTOR_SUITECRM' => 'SuiteCRM - Dünya için Açık Kaynak Kodlu Müşteri İlişkileri Yönetimi',
    'LBL_CONTRIBUTOR_SECURITY_SUITE' => 'Jason Eggers tarafından SecuritySuite geliştirildi',
    'LBL_CONTRIBUTOR_JJW_GMAPS' => 'Jeffrey J. Walters tarafından JJWDesign Google Haritaları geliştirildi',
    'LBL_CONTRIBUTOR_CONSCIOUS' => 'Conscious Solutions tarafından SuiteCRM Logosu tasarlandı',
    'LBL_CONTRIBUTOR_RESPONSETAP' => 'ResponseTap tarafından SuiteCRM 7.3 sürümüne yapılan katkılar',
    'LBL_CONTRIBUTOR_GMBH' => 'İş Akışına Göre Hesaplanan Alanlar diligent technology & business consulting GmbH tarafından sağlanmıştır',

    'LBL_LANGUAGE_ABOUT' => 'SuiteCRM Çevirileri Hakkında',
    'LBL_LANGUAGE_COMMUNITY_ABOUT' => 'Çevirilier SuiteCRM Topluluğu tarafından yapılıyor',
    'LBL_LANGUAGE_COMMUNITY_PACKS' => 'Çeviriler Crowdin üzerinde yapılıyor',

    'LBL_ABOUT_SUITE_2' => 'SuiteCRM projesi açık kaynak kodlu bir lisans altında yayınlanıyor - AGPLv3',
    'LBL_ABOUT_SUITE_4' => 'Proje tarafından yönetilen ve geliştirilen tüm SuiteCRM kodları açık kaynak kodlu olarak yayınlanır - AGPLv3',
    'LBL_ABOUT_SUITE_5' => 'Ücretli ve ücretsiz SuiteCRM desteği alınabilir',

    'LBL_SUITE_PARTNERS' => 'Açık kaynak fikrine tutkuyla bağlı sadık SuiteCRM iş ortaklarımız var. İş ortağı listemizin tamamını görebilmek için web sitemize bakın.',

    'LBL_SAVE_BUTTON' => 'Kaydet',
    'LBL_DELETE_BUTTON' => 'Sil',
    'LBL_APPLY_BUTTON' => 'Uygula',
    'LBL_SEND_INVITES' => 'Kaydet ve Çağrıları Gönder',
    'LBL_CANCEL_BUTTON' => 'İptal',
    'LBL_CLOSE_BUTTON' => 'Kapat',

    'LBL_CREATE_NEW_RECORD' => 'İşlem Ekle',
    'LBL_CREATE_CALL' => 'Telefon Aramasını Günlüğe Kaydet',
    'LBL_CREATE_MEETING' => 'Toplantı Zamanla',

    'LBL_GENERAL_TAB' => 'Ayrıntılar',
    'LBL_PARTICIPANTS_TAB' => 'Çağrılanlar',
    'LBL_REPEAT_TAB' => 'Yinelenme',

    'LBL_REPEAT_TYPE' => 'Yinele',
    'LBL_REPEAT_INTERVAL' => 'Her',
    'LBL_REPEAT_END' => 'Son',
    'LBL_REPEAT_END_AFTER' => 'Sonra',
    'LBL_REPEAT_OCCURRENCES' => 'yinelenme',
    'LBL_REPEAT_END_BY' => 'Sıklık',
    'LBL_REPEAT_DOW' => 'Zaman',
    'LBL_REPEAT_UNTIL' => 'Yinelenme Sonu Tarihi',
    'LBL_REPEAT_COUNT' => 'Yinelenme sayısı',
    'LBL_REPEAT_LIMIT_ERROR' => 'İsteğiniz $limit değerinden daha fazla toplantı oluşturacak.',

    //Events
    'LNK_EVENT' => 'Etkinlik',
    'LNK_EVENT_VIEW' => 'Etkinliği Görüntüle',
    'LBL_DATE' => 'Tarih: ',
    'LBL_DURATION' => 'Süre: ',
    'LBL_NAME' => 'Başlık: ',
    'LBL_HOUR_ABBREV' => 'saat',
    'LBL_HOURS_ABBREV' => 'saat',
    'LBL_MINSS_ABBREV' => 'dakika',
    'LBL_LOCATION' => 'Konum:',
    'LBL_STATUS' => 'Durum:',
    'LBL_DESCRIPTION' => 'Açıklama: ',
    //End Events

    'LBL_ELASTIC_SEARCH_EXCEPTION_SEARCH_INVALID_REQUEST' => 'Arama yapılırken bir sorun çıktı. Sorgu söz dizimi geçersiz olabilir.',
    'LBL_ELASTIC_SEARCH_EXCEPTION_SEARCH_ENGINE_NOT_FOUND' => 'İstenilen Arama Motoru bulunamadı. Lütfen yeniden aramayı deneyin.',
    'LBL_ELASTIC_SEARCH_EXCEPTION_NO_NODES_AVAILABLE' => 'Elasticsearch sunucusu ile bağlantı kurulamadı.',
    'LBL_ELASTIC_SEARCH_EXCEPTION_SEARCH' => 'Arama sırasında bir iç sorun çıktı.',
    'LBL_ELASTIC_SEARCH_EXCEPTION_DEFAULT' => 'Arama sırasında bilinmeyen bir sorun çıktı.',
    'LBL_ELASTIC_SEARCH_EXCEPTION_END_MESSAGE' => 'Contact an administrator if the problem persists. More information available in the logs.',

    'LBL_ELASTIC_SEARCH_DEFAULT' => 'Arama ölçütlerinize uyan bir sonuç yok. Arama ölçütlerinizi genişletmeyi deneyin.',

    'LNK_TASK_VIEW' => 'Görevi Görüntüle',

);
